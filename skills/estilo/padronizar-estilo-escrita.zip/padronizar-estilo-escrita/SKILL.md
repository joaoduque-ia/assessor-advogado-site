---
name: "padronizar-estilo-escrita"
description: "Extrai o estilo de redação jurídica (não a formatação nem o conteúdo) das peças do aluno ou do escritório e o transforma numa skill pessoal de escrita, com métricas e conferência da minuta."
---

# Padronizar o estilo de escrita das minhas peças

O usuário anexa ou indica peças que já redigiu (.docx de preferência; .pdf com texto também
serve). O objetivo é produzir uma SKILL DE ESTILO personalizada, para que toda peça futura
soe como o escritório escreve: ritmo dos parágrafos, aberturas e fechos, conectivos,
vocabulário, fórmulas fixas, modo de introduzir julgados e de pedir. Não é skill de modelo
de peça nem de formatação: o mérito das petições não é copiado, resumido nem avaliado, e a
forma gráfica (fonte, margens, recuos, logo) fica com a skill de formatação
(`padronizar-formatacao-pecas` / `formatacao-<nome>`). As duas são independentes e se
somam: primeiro se escreve com o estilo, depois se formata.

Entregáveis, sempre os quatro: (1) proposta de skill nova via `propose_skills`, nome
`estilo-<sobrenome-ou-escritorio>`; (2) o arquivo de regras em Markdown, idêntico ao corpo da
skill, para o usuário guardar na pasta das peças ou anexar em outra ferramenta; (3) uma
demonstração "antes e depois" com o resultado da conferência; (4) relatório curto na
conversa.

## Passo 0. Montar o corpus

Mínimo de 3 peças; o ideal é de 5 a 10, do mesmo autor ou da mesma equipe, recentes, de
tipos variados (inicial, contestação, recurso, manifestação). Pedir que sejam peças escritas
pelo próprio escritório, sem IA: se os modelos já foram gerados por IA, a skill aprende o
estilo da IA. Com menos de 3, avisar que o perfil será frágil e seguir só se o usuário
quiser. Com autores misturados e estilos visivelmente diferentes, perguntar se quer um
perfil por autor.

Peças contêm dados pessoais. Nada de nome de parte, CPF, endereço, número de processo,
valor ou fato do caso entra na skill. Exemplos de frases do escritório vão com
placeholders: `[PARTE]`, `[PROCESSO]`, `[DATA]`, `[VALOR]`, `[JUÍZO]`.

## Passo 1. Medir (quantitativo)

Salvar o script abaixo como `estilo_metricas.py` numa pasta própria (fora da pasta das peças)
e rodar com `python3 -I`. Ele lê .docx (separa corpo, títulos e citações recuadas) e .md/.txt
(linha iniciada por `>` é citação, `#` é título). Para PDF: `pdftotext` e montar um .md com
um parágrafo por linha e as citações marcadas com `>`.

```
python3 -I estilo_metricas.py perfil perfil.json peca1.docx peca2.docx peca3.docx
python3 -I estilo_metricas.py conferir perfil.json minuta.docx
```

Ementas, artigos de lei e trechos transcritos ficam fora das métricas, porque não são a voz
do escritório. O perfil traz: distribuição de palavras por parágrafo e por frase (mínimo,
quartis, máximo, coeficiente de variação), faixas de tamanho, parágrafos de uma frase,
aberturas de 1, 2 e 3 palavras, fechos, conectivos e marcas típicas de texto de IA por mil
palavras, tratamento do juízo, autorreferência, pontuação, `art.` contra `artigo`, emojis,
parágrafos vazios em sequência, títulos, frases que introduzem citações e fórmulas
recorrentes (trigramas e quadrigramas presentes em pelo menos duas peças, o que também filtra
nomes próprios de um caso só).

Teste cego, com 4 peças ou mais: gerar o perfil sem uma delas e rodar `conferir` nela. Peça
do próprio escritório deve sair com poucos alertas; se sair com muitos, o corpus é
heterogêneo ou um limite está apertado, e isso vai para o relatório.

```python
#!/usr/bin/env python3
"""Estilometria de peças jurídicas.
Uso:
  python3 -I estilo_metricas.py perfil  saida.json peca1.docx peca2.docx ...
  python3 -I estilo_metricas.py conferir perfil.json minuta.docx|minuta.md
"""
import sys, re, json, statistics as st
from collections import Counter

CONECTIVOS = ["ademais", "outrossim", "com efeito", "ocorre que", "nesse sentido", "nesse diapasão",
    "dessa forma", "desse modo", "assim", "portanto", "logo", "contudo", "todavia", "entretanto",
    "no entanto", "porém", "por outro lado", "além disso", "inclusive", "ou seja", "isto é",
    "por fim", "ante o exposto", "diante do exposto", "pelo exposto", "destarte", "nessa linha",
    "registre-se", "frise-se", "note-se", "veja-se", "cumpre", "impende", "convém"]
MARCAS_IA = ["vale ressaltar", "vale destacar", "é importante destacar", "é importante ressaltar",
    "é fundamental", "é crucial", "crucial", "robusto", "robusta", "em suma", "em síntese",
    "nesse contexto", "neste contexto", "não apenas", "mas também", "inegável", "inegavelmente",
    "cristalino", "cristalina", "salutar", "de suma importância", "cabe destacar", "importa destacar",
    "evidencia-se", "resta evidente", "fica evidente", "no cenário", "panorama", "arcabouço",
    "pilar", "pilares", "à luz de", "sob essa ótica", "como um todo", "de forma significativa"]
TRATAMENTO = ["vossa excelência", "v. exa.", "v. exa", "excelência", "mm.", "douto", "nobre julgador",
    "egrégio", "egrégia", "colenda", "colendo", "eminente", "excelentíssimo", "excelentíssima"]
AUTORREF = ["a defensoria pública", "a defensoria", "este subscritor", "esta subscritora", "o subscritor",
    "requer-se", "requer", "requeremos", "pugna", "pugna-se", "o assistido", "a assistida",
    "o recorrente", "a recorrente", "a parte autora", "o autor", "a autora", "o requerente"]
EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿⭐✅]")
ABREV = re.compile(r"\b(art|arts|inc|fls|exa|exas|n|nº|p|pág|min|rel|des|dr|dra|sr|sra|v|cf|ex|ss|al|mm|STJ|STF|Lei)\.$", re.I)

def norm(s):
    return re.sub(r"\s+", " ", s.replace("\xa0", " ")).strip()

def ler(caminho):
    """Lista de (tipo, texto) com tipo em corpo, citacao, titulo, vazio."""
    blocos = []
    if caminho.lower().endswith(".docx"):
        import docx
        d = docx.Document(caminho)
        for p in d.paragraphs:
            t = norm(p.text)
            if not t:
                blocos.append(("vazio", "")); continue
            nome = (p.style.name or "").lower()
            ind = p.paragraph_format.left_indent
            recuo_cm = ind.cm if ind is not None else 0
            if "quote" in nome or "cita" in nome or recuo_cm >= 2:
                blocos.append(("citacao", t)); continue
            palavras = t.split()
            todo_negrito = all(r.bold for r in p.runs if r.text.strip())
            if "heading" in nome or "título" in nome or "titulo" in nome or (
                    len(palavras) <= 14 and (t.upper() == t or todo_negrito) and not t.endswith((".", ";", ","))):
                blocos.append(("titulo", t)); continue
            blocos.append(("corpo", t))
    else:
        txt = open(caminho, encoding="utf-8").read()
        for bruto in re.split(r"\n", txt):
            t = norm(bruto)
            if not t:
                blocos.append(("vazio", "")); continue
            if t.startswith(">"):
                blocos.append(("citacao", t.lstrip("> "))); continue
            if t.startswith("#") or (len(t.split()) <= 14 and t.upper() == t):
                blocos.append(("titulo", t.lstrip("# "))); continue
            blocos.append(("corpo", t))
        # em .md/.txt um parágrafo vazio entre parágrafos é normal; só conta 2+ seguidos
    return blocos

def frases(t):
    partes, atual = [], ""
    for tok in re.split(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ\"“(])", t):
        atual = (atual + " " + tok).strip()
        if not ABREV.search(atual.split()[-1] if atual.split() else ""):
            partes.append(atual); atual = ""
    if atual: partes.append(atual)
    return partes

def abertura(t, n):
    w = re.findall(r"[\wÀ-ÿ\-]+", t.lower())
    return " ".join(w[:n])

def fecho(t):
    w = re.findall(r"[\wÀ-ÿ\-]+", t.lower())
    return " ".join(w[-3:])

def conta(lista, texto_lower):
    return {k: len(re.findall(r"(?<![\wÀ-ÿ])" + re.escape(k) + r"(?![\wÀ-ÿ])", texto_lower)) for k in lista}

def por_mil(c, total):
    return {k: round(v * 1000 / total, 2) for k, v in c.items() if v}

def quartis(v):
    v = sorted(v)
    if len(v) < 2: return {"min": v[0] if v else 0, "mediana": v[0] if v else 0, "max": v[-1] if v else 0}
    q = st.quantiles(v, n=4)
    return {"n": len(v), "min": v[0], "p25": round(q[0]), "mediana": round(st.median(v)), "p75": round(q[2]),
            "max": v[-1], "media": round(st.mean(v), 1), "cv": round(st.pstdev(v) / st.mean(v), 2)}

def metricas(docs):
    corpo = [t for d in docs for (k, t) in d if k == "corpo"]
    texto = " ".join(corpo); tl = texto.lower(); total = max(len(texto.split()), 1)
    tam = [len(t.split()) for t in corpo]
    fr = [len(f.split()) for t in corpo for f in frases(t)]
    vazios_seguidos = sum(1 for d in docs for i in range(1, len(d)) if d[i][0] == d[i-1][0] == "vazio")
    repet = sum(1 for d in docs for a, b in zip([t for k, t in d if k == "corpo"], [t for k, t in d if k == "corpo"][1:])
                if abertura(a, 2) == abertura(b, 2))
    return {
        "palavras_corpo": total, "paragrafos_corpo": len(corpo),
        "palavras_por_paragrafo": quartis(tam),
        "faixas_paragrafo": {f: sum(1 for x in tam if a <= x <= b) for f, (a, b) in
                             {"1-30": (1, 30), "31-60": (31, 60), "61-100": (61, 100), "101-150": (101, 150), "151+": (151, 10**6)}.items()},
        "paragrafos_de_uma_frase": sum(1 for t in corpo if len(frases(t)) == 1),
        "palavras_por_frase": quartis(fr),
        "aberturas_1": Counter(abertura(t, 1) for t in corpo).most_common(25),
        "aberturas_2": Counter(abertura(t, 2) for t in corpo).most_common(25),
        "aberturas_3": Counter(abertura(t, 3) for t in corpo).most_common(20),
        "fechos_3": Counter(fecho(t) for t in corpo).most_common(15),
        "aberturas_repetidas_em_sequencia": repet,
        "conectivos_por_mil": por_mil(conta(CONECTIVOS, tl), total),
        "marcas_ia_por_mil": por_mil(conta(MARCAS_IA, tl), total),
        "tratamento": {k: v for k, v in conta(TRATAMENTO, tl).items() if v},
        "autorreferencia": {k: v for k, v in conta(AUTORREF, tl).items() if v},
        "pontuacao_por_mil": {s: round(texto.count(c) * 1000 / total, 2) for s, c in
                              {"ponto_e_virgula": ";", "dois_pontos": ":", "parenteses": "(", "aspas_retas": '"',
                               "aspas_curvas": "“", "travessao_em": "—", "meia_risca": "–", "exclamacao": "!"}.items()},
        "art_abreviado": len(re.findall(r"\bart\.", tl)), "artigo_por_extenso": len(re.findall(r"\bartigos?\b", tl)),
        "emojis": len(EMOJI.findall(texto)),
        "vazios_consecutivos": vazios_seguidos,
        "titulos": [t for d in docs for k, t in d if k == "titulo"][:60],
        "introducoes_de_citacao": [d[i-1][1][-160:] for d in docs for i in range(1, len(d))
                                   if d[i][0] == "citacao" and d[i-1][0] == "corpo"][:30],
    }

def formulas(docs, minimo_docs=2):
    """Trigramas e quadrigramas que aparecem em pelo menos `minimo_docs` peças (fórmulas do escritório)."""
    presenca, freq = Counter(), Counter()
    for d in docs:
        w = re.findall(r"[\wÀ-ÿ\-]+", " ".join(t for k, t in d if k == "corpo").lower())
        grams = [" ".join(w[i:i+n]) for n in (3, 4) for i in range(len(w) - n + 1)]
        freq.update(grams); presenca.update(set(grams))
    return [(g, freq[g], presenca[g]) for g, _ in freq.most_common(4000) if presenca[g] >= minimo_docs][:60]

def perfil(saida, arquivos):
    docs = [ler(a) for a in arquivos]
    m = metricas(docs)
    m["formulas_recorrentes"] = formulas(docs, 2 if len(docs) > 1 else 1)
    m["por_peca"] = {a.split("/")[-1]: quartis([len(t.split()) for k, t in d if k == "corpo"]) for a, d in zip(arquivos, docs)}
    json.dump(m, open(saida, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: m[k] for k in ("paragrafos_corpo", "palavras_por_paragrafo", "faixas_paragrafo",
                      "palavras_por_frase", "marcas_ia_por_mil", "pontuacao_por_mil")}, ensure_ascii=False, indent=1))

def conferir(perfil_json, minuta):
    p = json.load(open(perfil_json, encoding="utf-8"))
    d = ler(minuta); m = metricas([d]); alertas = []
    pp, mp = p["palavras_por_paragrafo"], m["palavras_por_paragrafo"]
    if mp.get("cv", 0) < 0.6 * pp.get("cv", 0):
        alertas.append(f"Parágrafos uniformes demais: variação {mp.get('cv')} contra {pp.get('cv')} do escritório.")
    longos = [len(t.split()) for k, t in d if k == "corpo" and len(t.split()) > pp["max"]]
    if longos: alertas.append(f"{len(longos)} parágrafo(s) acima do maior do escritório ({pp['max']} palavras).")
    if pp.get("p25", 0) and mp.get("min", 0) > pp["p25"]:
        alertas.append("Nenhum parágrafo curto: o escritório tem 1/4 dos parágrafos com até "
                       f"{pp['p25']} palavras.")
    for k, v in m["marcas_ia_por_mil"].items():
        limite = p["marcas_ia_por_mil"].get(k, 0)
        if v > max(limite * 1.5, limite + 0.5):
            alertas.append(f"Marca de texto de IA \"{k}\": {v}/mil palavras (escritório: {limite}).")
    for k, v in m["conectivos_por_mil"].items():
        limite = p["conectivos_por_mil"].get(k, 0)
        if limite == 0 or v > limite * 2.5 + 1:
            alertas.append(f"Conectivo \"{k}\": {v}/mil palavras (escritório: {limite}).")
    if m["pontuacao_por_mil"]["travessao_em"] > p["pontuacao_por_mil"]["travessao_em"]:
        alertas.append("Travessão (—) acima do uso do escritório.")
    if m["emojis"]: alertas.append(f"{m['emojis']} emoji(s).")
    if m["vazios_consecutivos"]: alertas.append(f"{m['vazios_consecutivos']} parágrafo(s) vazio(s) em sequência.")
    if m["aberturas_repetidas_em_sequencia"]:
        alertas.append(f"{m['aberturas_repetidas_em_sequencia']} par(es) de parágrafos seguidos com a mesma abertura.")
    corpo = [t for k, t in d if k == "corpo"]
    if any(re.match(r"^([-•*]|\d+\))\s", t) for t in corpo): alertas.append("Marcadores de lista no corpo.")
    if any("**" in t or t.startswith("#") for t in corpo): alertas.append("Marcação Markdown (** ou #) no texto.")
    a1 = Counter(abertura(t, 1) for t in corpo)
    for w, c in a1.items():
        base = dict((x, y) for x, y in p["aberturas_1"]).get(w, 0) / max(p["paragrafos_corpo"], 1)
        if len(corpo) >= 5 and c / len(corpo) > max(base * 2, 0.2):
            alertas.append(f"Abertura \"{w}\" em {c} de {len(corpo)} parágrafos (escritório: {round(base*100)}%).")
    print(json.dumps({"minuta": {"palavras_por_paragrafo": mp, "palavras_por_frase": m["palavras_por_frase"]},
                      "escritorio": {"palavras_por_paragrafo": pp, "palavras_por_frase": p["palavras_por_frase"]},
                      "alertas": alertas or ["Nenhum alerta."]}, ensure_ascii=False, indent=1))

if __name__ == "__main__":
    if len(sys.argv) < 4 or sys.argv[1] not in ("perfil", "conferir"):
        sys.exit(__doc__)
    perfil(sys.argv[2], sys.argv[3:]) if sys.argv[1] == "perfil" else conferir(sys.argv[2], sys.argv[3])
```

## Passo 2. Ler (qualitativo)

Os números não veem tudo. Ler por inteiro ao menos duas peças de tipos diferentes e
registrar, sempre com a frequência observada e não com impressão:

- Voz: quem fala (primeira pessoa, "a Defensoria", "o autor", voz passiva sintética como
  "requer-se"), como se nomeia a própria parte, a parte contrária e o juízo.
- Tom: sóbrio ou combativo; se usa ironia, pergunta retórica, adjetivação contra a decisão
  ou a parte contrária; até onde vai a contundência.
- Arquitetura do argumento: em que ordem o escritório costuma pôr fato, norma, julgado e
  aplicação ao caso; se fecha cada tópico com um parágrafo de conclusão ou passa direto.
- Julgados: frase que introduz a citação, se comenta depois e com que tamanho, se usa "grifo
  nosso", se cita número do processo no texto ou só na referência.
- Remissões legais: `art. 300 do CPC` ou `artigo 300 do Código de Processo Civil`; se escreve
  o nome por extenso na primeira menção.
- Pedidos e fecho: fórmula de transição ("Ante o exposto", "Diante do exposto"), forma dos
  pedidos (alíneas, verbos no infinitivo, "requer seja"), fecho ("Nestes termos, pede
  deferimento", local e data).
- Ênfase: o que o escritório destaca (palavra, expressão, frase inteira) e com que
  frequência. Como destacar graficamente (negrito, itálico, sublinhado) é assunto da skill de
  formatação; aqui se registra só o que costuma ser enfatizado.
- Latinismos e jargões: quais usa e quais nunca aparecem.

Separar estilo de defeito, como na formatação: erros de português, concordância, citação de
lei revogada e repetições acidentais não são estilo e não entram como regra. Registrar no
relatório o que foi descartado.

## Passo 3. Escrever a skill do usuário

SKILL.md com frontmatter (name `estilo-<nome>`; description dizendo que se aplica a toda peça
que o Claude redigir ou revisar para aquele usuário, antes da formatação) e:

1. Regra de ouro: estilo, não conteúdo. O mérito, os fatos e os pedidos vêm do caso e do
   usuário; nunca inventar fato, prova, número ou julgado para "soar como o escritório".
   Citação transcrita é fiel à fonte e não se reescreve no estilo. Julgado sem conferência
   na fonte oficial vira "[VERIFICAR JULGADO]".
2. Voz e tratamento: quem fala, como chama cada parte e o juízo (com os termos do perfil).
3. Ritmo dos parágrafos, em números do corpus: mediana, quartis, máximo e as faixas, e a
   regra prática derivada (por exemplo: "metade dos parágrafos entre X e Y palavras; ao
   menos um parágrafo de uma frase por tópico; nunca três parágrafos seguidos da mesma
   faixa; nenhum acima de Z palavras"). Mesmo tratamento para frases.
4. Aberturas: as que o escritório usa, com a frequência relativa; proibido repetir a mesma
   abertura em parágrafos seguidos e usar como muleta abertura ausente do corpus.
5. Fechos de parágrafo e de tópico: como o escritório termina; se não encerra parágrafo com
   frase de efeito ou "moral da história", isso vira regra.
6. Conectivos: preferidos (com frequência), raros e nunca usados.
7. Vocabulário e fórmulas fixas: as fórmulas recorrentes do perfil, já sem dados do caso, e
   até cinco exemplos curtos de frases-modelo com placeholders.
8. Julgados e remissões legais: introdução, comentário, forma de citar artigo e lei.
9. Pedidos e fecho.
10. Pontuação: uso de ponto e vírgula, dois-pontos, parênteses, aspas; travessão só se o
    escritório usa.
11. Lista negra: (a) cada marca de texto de IA da lista do script que não aparece no corpus
    ou aparece abaixo de 0,5 por mil palavras; (b) sempre, salvo se o corpus mostrar o
    contrário: emoji, travessão, marcadores de lista no corpo da argumentação, Markdown,
    parágrafo vazio para separar parágrafos, títulos em forma de pergunta, a construção
    "não apenas X, mas também Y", enumerações em trio repetidas, adjetivos de ênfase vazia
    ("crucial", "robusto", "inegável", "cristalino") e parágrafos todos do mesmo tamanho.
12. Conferência obrigatória antes de entregar: o script completo (copiado sem alteração) e,
    entre `<!-- PERFIL-INICIO -->` e `<!-- PERFIL-FIM -->`, o JSON do perfil reduzido às
    chaves usadas pelo `conferir` (`paragrafos_corpo`, `palavras_por_paragrafo`,
    `palavras_por_frase`, `aberturas_1`, `conectivos_por_mil`, `marcas_ia_por_mil`,
    `pontuacao_por_mil`), com instrução de salvar o bloco como `perfil.json` sem
    interpretá-lo. Fluxo: redigir, salvar a minuta (.md ou .docx), rodar `conferir`, corrigir
    cada alerta reescrevendo o trecho (não apenas trocando palavras), rodar de novo até sobrar
    só o que for justificável, e informar os alertas remanescentes.
13. Integração: se existir `formatacao-<nome>`, aplicá-la depois da conferência de estilo.

Regras com números sempre que o perfil der números; nada de regra genérica que valeria para
qualquer escritório. A skill não promete enganar detector de IA. O objetivo é que a peça
tenha a voz e a qualidade do escritório; a revisão e a responsabilidade continuam sendo do
profissional que assina.

## Passo 4. Demonstrar e entregar

Demonstração "antes e depois" sem dado real de caso: escrever um tópico curto e genérico
(por exemplo, uma preliminar de nulidade por falta de intimação, com `[PARTE]` e
`[PROCESSO]`) primeiro sem a skill e depois aplicando a skill; rodar `conferir` nas duas
versões e mostrar os alertas de cada uma. Salvar em `demonstracao-estilo-<nome>.md` (e em
.docx pela skill de formatação do usuário, se houver). Rodar o teste cego do Passo 1, se o
corpus permitir.

Enviar o arquivo de regras `estilo-<nome>.md` (idêntico ao corpo da skill), a demonstração e
o `perfil.json`. Chamar `propose_skills` com a SKILL.md completa. Fechar com o relatório:
tamanho do corpus, perfil em poucas linhas (ritmo, aberturas, conectivos, voz), o que foi
descartado como defeito, resultado do teste cego e as marcas que entraram na lista negra.

Sem peça anexada, pedir ao menos três em .docx; não inventar um estilo.