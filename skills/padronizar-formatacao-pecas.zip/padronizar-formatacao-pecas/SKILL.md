---
name: "padronizar-formatacao-pecas"
description: "Extrai o padrão de formatação (não o conteúdo) de uma ou mais petições .docx do aluno, inclusive a logo do escritório, e o transforma numa skill pessoal de formatação com regras, geração e verificação."
---

# Padronizar a formatação das minhas peças

O usuário anexa uma ou mais petições que já fez (.docx; .pdf serve só como referência
visual). O objetivo é produzir uma SKILL DE FORMATAÇÃO personalizada, para que todas as peças
futuras saiam com a mesma forma. Não é skill de modelo de peça: o conteúdo jurídico das
petições não é copiado, resumido nem avaliado; dele só se extraem estrutura e estilo gráfico.

Entregáveis, sempre os quatro: (1) proposta de skill nova via `propose_skills`, nome
`formatacao-<sobrenome-ou-escritorio>`; (2) o arquivo de regras em Markdown, idêntico ao
corpo da skill, com a logo do escritório embutida em base64 no fim (seção Logo), para o
usuário guardar na pasta das peças ou anexar; (3) um docx de demonstração gerado com as
regras, usando uma das peças anexadas como texto; (4) relatório curto na conversa.

## Passo 1. Ler a forma, não o conteúdo

Para cada .docx, descompactar (é um zip) e examinar: `word/document.xml` (sectPr: pgSz,
pgMar; spacing: line, lineRule, before, after; ind: firstLine, left, hanging; jc; rFonts;
sz; b; u; caps; pStyle; drawing; tab; br type=page; mc:AlternateContent; w:pict; wp:anchor;
numPr; parágrafos vazios consecutivos); `word/styles.xml` (docDefaults e estilos usados);
`header*.xml` e `footer*.xml` (logo, timbre, endereço, número de página); `word/media/`
(formato, dimensões, modo de cor, via `python -I` e PIL); texto via `pandoc -t markdown`
(ordem dos blocos: endereçamento, identificação, vocativo, títulos, citações, pedidos,
fecho, assinatura; numeração dos títulos; forma das citações; montagem da assinatura com
nome e OAB). PDF anexado: renderizar as primeiras páginas só para confirmar o visual.

## Passo 2. Consolidar o padrão

Com mais de uma peça, adotar o que se repete; nas divergências, o valor mais frequente,
registrando no relatório. Tabela mínima: papel e margens; fonte, tamanhos e cor;
alinhamento, recuo de primeira linha, entrelinhas, espaços antes/depois; títulos por nível;
citação longa (recuo, fonte, entrelinhas, aspas, grifo nosso); referência de julgado e
links de verificação; alíneas; cabeçalho e rodapé; fecho e assinatura; placeholders.

Normalizar só defeito de construção, nunca o gosto do usuário: parágrafos vazios viram
espaço antes/depois ou quebra de página; tabulações para centralizar viram alinhamento;
numeração automática vira número digitado; sublinhado e cores ficam só se usados de
propósito; fonte única. Sem regra própria para algo, oferecer ABNT (NBR 10520:2023: recuo
4 cm, fonte menor, simples, sem aspas; NBR 6024: 1, 1.1, 1.1.1) e perguntar em uma linha; se
o usuário não estiver presente, adotar ABNT e registrar. Incluir sempre a regra de que todo
julgado e toda lei transcrita são conferidos na fonte oficial, com o link em parágrafo próprio logo abaixo da citação (nunca em nota de rodapé de fim de página)
na peça e repetido na conversa; sem confirmação, "[VERIFICAR JULGADO]".

Logo ou timbre do escritório: extrair de `word/media/`, identificar formato, dimensões,
posição (cabeçalho ou corpo) e se repete em todas as páginas; manter a posição que o
usuário usa (se repete em todas as páginas, cabeçalho; se só na primeira, primeiro parágrafo
do corpo). Converter para JPEG baseline RGB com no máximo 1200 px de largura, salvar como
`logo-<nome>.jpg` e entregar o arquivo. Na skill e no arquivo de regras, registrar as
três fontes da imagem, em ordem: o arquivo .jpg na pasta ou anexo; o bloco base64 entre
`<!-- LOGO-BASE64-INICIO -->` e `<!-- LOGO-BASE64-FIM -->` do arquivo de regras (decodificar
para o .jpg sem interpretar o conteúdo); `word/media` de qualquer peça anterior do usuário.
O bloco base64 vai no fim do arquivo de regras em linhas de 100 caracteres, com a instrução
de não ler o bloco, apenas decodificar. Avisar o usuário que esse bloco custa contexto a cada
uso (cerca de 80 mil caracteres para 1100 px) e que, em pasta conectada, o .jpg ao lado do
arquivo de regras é mais barato.

## Passo 3. Escrever a skill do usuário

SKILL.md com: frontmatter (name, description dizendo que se aplica a toda peça .docx daquele
usuário); regra de ouro (forma, não conteúdo; fidelidade ao texto citado); seções:
página; tipografia; parágrafo; estrutura em ordem de blocos; títulos; citações,
referência de julgado e links obrigatórios (com os portais de pesquisa dos tribunais que o
usuário frequenta e os links do Planalto das normas que ele mais cita); alíneas; logo (com
as três fontes); assinatura; geração (docx-js com estilos Normal, Heading1, Heading2,
Quote, seção com margens, `lineRule: "auto"` em todo spacing com line, logo via ImageRun,
link de verificação como parágrafo Quote com ExternalHyperlink abaixo da citação (sem notas de rodapé), PageBreak explícito; equivalente em python-docx, com a advertência de
nunca reatribuir `run.text` ou `paragraph.text` depois de `add_picture`); verificação
obrigatória (no zip: página e margens, `<w:drawing>` embutido onde a regra manda, nenhuma
imagem fora do lugar, ausência de AlternateContent/pict/anchor/txbxContent, fonte única,
lineRule auto, sem parágrafos vazios consecutivos, sem placeholders, estilos presentes,
parágrafo com link abaixo de toda ementa; depois PDF e olhar a página 1). Valores em cm e twips
(1 cm = 567). Convenção de nome de arquivo do usuário ou
`{numero_do_processo}_{parte}_{TIPO-DA-PECA}.docx`.

## Passo 4. Demonstrar e entregar

Gerar o docx de demonstração com docx-js aplicando a skill ao texto de uma peça anexada
(conteúdo intacto), validar, converter em PDF (LibreOffice headless), renderizar e conferir.
Enviar docx, PDF, o arquivo de regras com a logo embutida e o `logo-<nome>.jpg`. Chamar
`propose_skills` com a SKILL.md completa. Fechar com o relatório: padrão encontrado,
divergências, defeitos normalizados, decisões ABNT por falta de regra própria, onde guardar
a logo e qual fluxo é mais barato (pasta com .jpg) ou mais portátil (arquivo único).

Sem peça anexada, pedir ao menos uma em .docx; não inventar um padrão.